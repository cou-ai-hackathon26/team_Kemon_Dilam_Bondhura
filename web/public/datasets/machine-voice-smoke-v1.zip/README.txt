Capzoryx voice smoke corpus
30 synthetic machine-voiced statements in English, Bangla and transliterated Bangla. eSpeak NG uses its English voice for the Latin-script samples. These clips exercise recording and parser integration. Independent human-speaker validation requires a separate consented corpus.
